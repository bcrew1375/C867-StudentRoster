#ifndef DEGREE
#define DEGREE

enum Degree { SECURITY, NETWORK, SOFTWARE };

#endif